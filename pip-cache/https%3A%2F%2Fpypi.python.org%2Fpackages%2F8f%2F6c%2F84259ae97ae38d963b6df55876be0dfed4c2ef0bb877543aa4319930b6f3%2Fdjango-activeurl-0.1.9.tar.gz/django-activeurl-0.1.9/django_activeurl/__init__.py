'''easy to use active url highlighting for django'''
