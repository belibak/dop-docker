# -*- coding: utf-8 -*-
'''
Django.js provide better integration of javascript into Django.
'''

__version__ = '0.8.1'
__description__ = "Django JS Tools"

#: Packaged jQuery version
JQUERY_DEFAULT_VERSION = '2.0.3'
JQUERY_MIGRATE_VERSION = '1.2.1'
