# -*- coding: utf-8 -*-
'''
This package is dedicated to contributed compatibility modules.

These modules provide mixins and already packed
:class:`ContextSerializers <djangojs.context_serializer.ContextSerializer>`
to use Django applications incompatible with the defaut Django.js behavior.
'''
