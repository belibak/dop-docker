(function(){
window.DJANGO_JS_URLS = {{ urls|safe }};
window.DJANGO_JS_CONTEXT = {{ context|safe }};
}());
