=========================================
 Cache Backend - djcelery.backends.cache
=========================================

.. contents::
    :local:
.. currentmodule:: djcelery.backends.cache

.. automodule:: djcelery.backends.cache
    :members:
    :undoc-members:
