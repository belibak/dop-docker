# Import all the classes into api module
from . import kickbox
