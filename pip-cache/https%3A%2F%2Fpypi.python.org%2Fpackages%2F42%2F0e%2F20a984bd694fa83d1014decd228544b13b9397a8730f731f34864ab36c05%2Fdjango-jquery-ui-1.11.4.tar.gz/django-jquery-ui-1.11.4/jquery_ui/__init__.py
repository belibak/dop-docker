'''Django static files for jQuery UI'''
