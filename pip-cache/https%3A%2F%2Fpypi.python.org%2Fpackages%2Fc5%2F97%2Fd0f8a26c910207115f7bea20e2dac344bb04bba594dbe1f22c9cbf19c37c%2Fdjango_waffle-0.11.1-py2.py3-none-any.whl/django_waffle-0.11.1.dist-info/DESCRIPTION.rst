======
README
======

Django Waffle is (yet another) feature flipper for Django. You can
define the conditions for which a flag should be active, and use it in
a number of ways.

.. image:: https://travis-ci.org/jsocol/django-waffle.png?branch=master
   :target: https://travis-ci.org/jsocol/django-waffle
   :alt: Travis-CI Build Status

:Code:          https://github.com/jsocol/django-waffle
:License:       BSD; see LICENSE file
:Issues:        https://github.com/jsocol/django-waffle/issues
:Documentation: https://waffle.readthedocs.org/


