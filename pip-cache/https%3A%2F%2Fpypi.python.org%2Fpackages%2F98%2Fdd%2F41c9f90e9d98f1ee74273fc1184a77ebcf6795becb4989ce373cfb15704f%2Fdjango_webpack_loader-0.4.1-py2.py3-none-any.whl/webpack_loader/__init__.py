__author__ = 'Owais Lone'
__version__ = '0.4.1'

default_app_config = 'webpack_loader.apps.WebpackLoaderConfig'
