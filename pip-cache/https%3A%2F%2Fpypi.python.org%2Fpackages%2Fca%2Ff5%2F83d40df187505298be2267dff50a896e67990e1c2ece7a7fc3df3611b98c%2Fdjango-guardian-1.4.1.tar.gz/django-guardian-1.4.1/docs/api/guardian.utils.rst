.. _api-utils:

.. currentmodule:: guardian.utils

Utilities
=========

.. automodule:: guardian.utils


get_anonymous_user
------------------

.. autofunction:: get_anonymous_user

get_identity
------------

.. autofunction:: get_identity

clean_orphan_obj_perms
----------------------

.. autofunction:: clean_orphan_obj_perms

