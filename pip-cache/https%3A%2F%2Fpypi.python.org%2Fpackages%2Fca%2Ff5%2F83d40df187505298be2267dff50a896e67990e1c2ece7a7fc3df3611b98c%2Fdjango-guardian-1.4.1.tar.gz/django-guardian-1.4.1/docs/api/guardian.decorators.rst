.. _api-decorators:

Decorators
==========

.. automodule:: guardian.decorators


.. _api-decorators-permission_required:

permission_required
-------------------

.. autofunction:: guardian.decorators.permission_required


.. _api-decorators-permission_required_or_403:

permission_required_or_403
--------------------------

.. autofunction:: guardian.decorators.permission_required_or_403

