Credits
-------

Development Lead
~~~~~~~~~~~~~~~~

* Miroslav Shubernetskiy - https://github.com/miki725

Contributors
~~~~~~~~~~~~

* Arien Tolner - https://github.com/Bounder
* Davide Mendolia - https://github.com/davideme
* Kevin Brown - https://github.com/kevin-brown
* Martin Cavoj - https://github.com/macav
* Matthias Erll - https://github.com/merll
* Mjumbe Poe - https://github.com/mjumbewu
* Thomas Wajs - https://github.com/thomasWajs
* Xavier Ordoquy - https://github.com/xordoquy
