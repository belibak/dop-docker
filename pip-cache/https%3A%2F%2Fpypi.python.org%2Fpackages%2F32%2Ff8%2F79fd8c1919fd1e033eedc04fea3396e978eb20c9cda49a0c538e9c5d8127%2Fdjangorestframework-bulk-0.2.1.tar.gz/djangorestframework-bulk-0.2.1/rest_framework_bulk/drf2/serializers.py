from __future__ import print_function, unicode_literals


__all__ = [
    'BulkListSerializer',
    'BulkSerializerMixin',
]


class BulkSerializerMixin(object):
    pass


class BulkListSerializer(object):
    pass
