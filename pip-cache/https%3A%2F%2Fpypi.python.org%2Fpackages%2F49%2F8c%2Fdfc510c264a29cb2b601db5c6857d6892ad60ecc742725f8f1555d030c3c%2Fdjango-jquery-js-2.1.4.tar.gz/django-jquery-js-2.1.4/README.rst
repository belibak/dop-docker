=========================
jQuery bundled for Django
=========================

A Django app that contains jQuery as a static asset. Your packages can depend
upon this app to provide jQuery without bundling it.

License
=======

This application is licensed under the MIT license. See LICENSE for more information.

jQuery is licensed under the MIT license. See <https://jquery.org/license/> for more information.
