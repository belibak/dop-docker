from . import utils

def jquery(context):
    return {'jquery_path': utils.jquery_path}
